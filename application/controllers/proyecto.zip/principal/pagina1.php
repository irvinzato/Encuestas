<html>
    <body> 
        <h1> LOGEO DEL CHAMPS </h1>
        
        <br>
        <p> Usuario </p>
        <input type="text" name="Ingrear Usuario" value="">
        
        <br>
        <p> Contraseña </p>
        <input type="text" name="Ingrear Contraseña" value="">
        
        
    </body>
    
    

</html>


